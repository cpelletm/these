import sys
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from PyQt5.QtWidgets import QApplication,QFileDialog




def extract_data(filename,xcol=0,ycol=1):
	x=[]
	y=[]
	with open(filename,'r',encoding = "ISO-8859-1") as f:
		for line in f :
			line=line.split()
			try :
				x+=[float(line[xcol])]
				y+=[float(line[ycol])]
			except :
				pass
	return(np.array(x),np.array(y))

def lin_fit(x,y) :
	A=np.vstack([x,np.ones(len(x))]).T
	a,b = np.linalg.lstsq(A, y, rcond=None)[0]
	return(a,b,a*x+b)

def gauss_fit(x,y,Amp=None,x0=None,sigma=None,ss=0) :
	if not ss :
		ss=y[0]
	if not Amp :
		if max(y)-ss > ss-min(y) :
			Amp=max(y)-ss
		else :
			Amp=min(y)-ss
	if not x0 :
		x0=x[int(len(x)/2)]
	if not sigma :
		sigma=x[int(len(x)/5)]-x[0]
	def f(x,Amp,x0,sigma,ss) :
		return Amp*np.exp(-((x-x0)/(2*sigma))**2)+ss
	p0=[Amp,x0,sigma,ss]
	popt, pcov = curve_fit(f, x, y, p0)
	return(popt,f(x,popt[0],popt[1],popt[2],popt[3]))

def lor_fit(x,y,Amp=None,x0=None,sigma=None,ss=None) :
	if not ss :
		ss=y[0]
	if not Amp :
		if max(y)-ss > ss-min(y) :
			Amp=max(y)-ss
		else :
			Amp=min(y)-ss
	if not x0 :
		x0=x[int(len(x)/2)]
	if not sigma :
		sigma=x[int(len(x)/5)]-x[0]
	def f(x,Amp,x0,sigma,ss) :
		return ss+Amp*1/(1+((x-x0)/(2*sigma))**2)
	p0=[Amp,x0,sigma,ss]
	popt, pcov = curve_fit(f, x, y, p0)
	return(popt,f(x,popt[0],popt[1],popt[2],popt[3]))

def exp_fit(x,y,Amp=None,ss=None,tau=None) :
	if not Amp :
		Amp=max(y)-min(y)
	if not ss :
		ss=y[-1]
	if not tau :
		tau=x[int(len(x)/10)]-x[0]
	def f(x,Amp,ss,tau) :
		return Amp*np.exp(-x/tau)+ss
	p0=[Amp,ss,tau]
	popt, pcov = curve_fit(f, x, y, p0)
	return(popt,f(x,popt[0],popt[1],popt[2]))

def stretch_exp_fit(x,y,Amp=None,ss=None,tau=None) :
	if not Amp :
		Amp=max(y)-min(y)
	if not ss :
		ss=y[-1]
	if not tau :
		tau=x[int(len(x)/10)]-x[0]
	def f(x,Amp,ss,tau) :
		return Amp*np.exp(-np.sqrt(x/tau))+ss
	p0=[Amp,ss,tau]
	popt, pcov = curve_fit(f, x, y, p0)
	return(popt,f(x,popt[0],popt[1],popt[2]))

def stretch_soustraction(x,y,Amp=None,tau=None) :
	if not Amp :
		Amp=max(y)-min(y)
	if not tau :
		tau=x[int(len(x)/10)]-x[0]
	def f(x,Amp,tau) :
		return Amp*np.exp(-np.sqrt(x/tau))
	p0=[Amp,tau]
	popt, pcov = curve_fit(f, x, y, p0)
	return(popt,f(x,popt[0],popt[1]))

def third_stretch(x,y,Amp=None,tau=None) :
	if not Amp :
		Amp=max(y)-min(y)
	if not tau :
		tau=x[int(len(x)/10)]-x[0]
	def f(x,Amp,tau) :
		return Amp*np.exp(-(x/tau)^(1/3))
	p0=[Amp,tau]
	popt, pcov = curve_fit(f, x, y, p0)
	return(popt,f(x,popt[0],popt[1]))

def stretch_et_phonon(x,y,Amp=None,tau=None) :
	if not Amp :
		Amp=max(y)-min(y)
	if not tau :
		tau=x[int(len(x)/10)]-x[0]
	def f(x,Amp,tau) :
		return Amp*np.exp(-np.sqrt(x/tau)-x/5E-3)
	p0=[Amp,tau]
	popt, pcov = curve_fit(f, x, y, p0)
	return(popt,f(x,popt[0],popt[1]))

def ask_name():
	qapp = QApplication(sys.argv)
	fname,filters=QFileDialog.getOpenFileName()	
	return fname


# fname='scan_rose_4x_0B_zoom_align3'
# x,y=extract_data(fname+'.txt')
# x2,y2=extract_data(fname+'.txt',xcol=2,ycol=3)
# y2=list(y2)
# xmin=y2.index(max(y2))
# xmax=y2.index(min(y2))
# y2=y2[xmin:xmax]
# y=y[xmin:xmax]
# plt.plot(y2,y)
# popt,yfit=lor_fit(y2,y)
# plt.plot(y2,yfit,label='lor, sigma=%f'%popt[2])


center=2.8648

# fname='ESR_4x_3V_zoom_align3'
# x,y=extract_data(fname+'.txt')
# y=y-min(y)
# y=y/max(y)
# y=list(y)
# mil=y.index(min(y))
# x=x+center-x[mil]
# plt.plot(x,y,label=fname)

x_transi=[17.953273372377286, 19.705551221857355, 24.31251459360322, 22.117301530072833]

# fname='scan_rose_100_7V_'
# x,y=extract_data(fname+'.txt')
# y=y/max(y)
# x=x-x[257]
# x=x*64
# plt.plot(x,y,label='Photoluminescence')

# fname='scan_100_rose_10V'
# x,y=extract_data(fname+'.txt')
# y=y/max(y)
# x=x-x[507]
# x=x*64
# plt.plot(x,y,label='Photoluminescence')

# fname='scan_adamas_gros_laser'
# x,y=extract_data(fname+'.txt')
# y=y/max(y)
# x=x+0.115
# x=x*68.1
# x=x[250:]
# y=y[250:]
# plt.plot(x,y,label='Photoluminescence')

# fname='scan_adamas_4_jours'
# x,y=extract_data(fname+'.txt')
# y=y/max(y)
# x=x-0.075
# x=x*68.1
# plt.plot(x,y,label='adamas petit laser')


# fname='scan_100_sample_ludo_accident'
# x,y=extract_data(fname+'.txt')
# y=y/max(y)
# x=x+0.167
# x=x*62
# plt.plot(x,y,label='Photoluminescence')

# fname='scan_100_sample_ludo_aligne_vitedeuf'
# x,y=extract_data(fname+'.txt')
# y=y/max(y)
# x=x+0.167
# x=x*62
# x=x[40:]
# y=y[40:]
# plt.plot(x,y,label='Photoluminescence')


fname='scan_100_symetrique'
x,y=extract_data(fname+'.txt')
y=y/max(y)
x=x-x[255]
x=x*65
plt.plot(x,y,label='Photoluminescence')

plt.xlabel('Magnetic field along (100) in G')
ax=plt.gca()
ylim=ax.get_ylim()


Cm=x_transi[0]
plt.plot([Cm,Cm],[0,2],ls='dotted',color='orange', label=' 13C transitions')
Cm=x_transi[1]
plt.plot([Cm,Cm],[0,2],ls='dotted',color='orange')
Cm=x_transi[2]
plt.plot([Cm,Cm],[0,2],ls='dotted',color='orange')
Cm=x_transi[3]
plt.plot([Cm,Cm],[0,2],ls='dotted',color='orange')
Cm=-x_transi[0]
plt.plot([Cm,Cm],[0,2],ls='dotted',color='orange')
Cm=-x_transi[1]
plt.plot([Cm,Cm],[0,2],ls='dotted',color='orange')
Cm=-x_transi[2]
plt.plot([Cm,Cm],[0,2],ls='dotted',color='orange')
Cm=-x_transi[3]
plt.plot([Cm,Cm],[0,2],ls='dotted',color='orange')

plt.ylim(ylim)

plt.legend()
plt.show()